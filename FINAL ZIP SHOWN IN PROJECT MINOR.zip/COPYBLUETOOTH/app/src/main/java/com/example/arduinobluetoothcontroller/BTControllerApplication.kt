package com.example.arduinobluetoothcontroller

import android.app.Application

class BTControllerApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        MedicineData.loadMedicines(this)

        // If the list is empty after loading, add the default medicine
        if (MedicineData.medicineList.isEmpty()) {
            MedicineData.medicineList.add(Medicine("Paracetamol"))
            MedicineData.saveMedicines(this)
        }
    }
}