package com.example.arduinobluetoothcontroller

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class StatusActivity : AppCompatActivity() {

    private var bluetoothService: BluetoothService? = null
    private var isBound = false

    private lateinit var tvTerminal: TextView
    private lateinit var tvConnection: TextView
    private lateinit var scrollView: ScrollView
    private val handler = Handler(Looper.getMainLooper())

    private val refreshTask = object : Runnable {
        override fun run() {
            if (isBound && bluetoothService?.isConnected() == true) {
                bluetoothService?.sendCommand("GETTIME") {}
            }
            handler.postDelayed(this, 1000)
        }
    }

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(className: ComponentName, service: IBinder) {
            val binder = service as BluetoothService.LocalBinder
            val s = binder.getService()
            bluetoothService = s
            isBound = true
            
            s.setMessageListener { message ->
                runOnUiThread {
                    onBluetoothMessage(message)
                }
            }
            updateConnection(true)
        }

        override fun onServiceDisconnected(arg0: ComponentName) {
            isBound = false
            bluetoothService = null
            updateConnection(false)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_status)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "System Terminal"

        tvTerminal = findViewById(R.id.tvTerminal)
        tvConnection = findViewById(R.id.tvConnection)
        scrollView = findViewById(R.id.scrollView)

        findViewById<Button>(R.id.btnClear).setOnClickListener {
            tvTerminal.text = ""
        }

        findViewById<Button>(R.id.btnSave).setOnClickListener {
            val file = File(getExternalFilesDir(null), "terminal_log.txt")
            file.writeText(tvTerminal.text.toString())
            Toast.makeText(this, "Saved to ${file.absolutePath}", Toast.LENGTH_LONG).show()
        }

        Intent(this, BluetoothService::class.java).also { intent ->
            bindService(intent, connection, Context.BIND_AUTO_CREATE)
        }

        log("Terminal Initialized")
        loadLastAlarm()
        updateConnection(isBound && bluetoothService?.isConnected() == true)
    }

    override fun onResume() {
        super.onResume()
        handler.post(refreshTask)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(refreshTask)
    }

    private fun log(msg: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())

        val colored = if (msg.contains("ALARM", ignoreCase = true) || msg.contains("TRIGGERED", ignoreCase = true) || msg.contains("🔔")) {
            SpannableString("[$time] $msg\n").apply {
                setSpan(ForegroundColorSpan(Color.YELLOW), 0, length, 0)
            }
        } else {
            SpannableString("[$time] $msg\n")
        }

        tvTerminal.append(colored)

        scrollView.post { scrollView.fullScroll(View.FOCUS_DOWN) }
    }

    fun updateConnection(connected: Boolean) {
        if (connected) {
            tvConnection.text = "Bluetooth: Connected"
            tvConnection.setTextColor(Color.GREEN)
        } else {
            tvConnection.text = "Bluetooth: Disconnected"
            tvConnection.setTextColor(Color.RED)
        }
    }

    fun onBluetoothMessage(msg: String) {
        log(msg) // Log to local terminal first

        when {
            msg.contains("ALARM TRIGGERED", ignoreCase = true) -> {
                val ledId = msg.substringAfter("LED").trim().toIntOrNull() ?: -1
                AppLogger.logToHomeTerminal("ALARM TRIGGERED LED$ledId")
            }
            msg.startsWith("RTC", ignoreCase = true) -> {
                val parts = msg.split(" ")
                if (parts.size >= 3) {
                    val time = parts[1]
                    val day = parts[2]
                    AppLogger.logToHomeTerminal("RTC ${time} ${day}")
                }
            }
        }
    }

    private fun loadLastAlarm() {
        val sharedPrefs = getSharedPreferences("MedicineApp", Context.MODE_PRIVATE)
        val lastAlarm = sharedPrefs.getString("last_alarm_info", "Not Set")
        if (lastAlarm != "Not Set") {
            log("Saved Config → $lastAlarm")
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            onBackPressedDispatcher.onBackPressed()
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isBound) {
            bluetoothService?.setMessageListener { } // Clear listener
            unbindService(connection)
            isBound = false
        }
        handler.removeCallbacks(refreshTask)
    }
}
