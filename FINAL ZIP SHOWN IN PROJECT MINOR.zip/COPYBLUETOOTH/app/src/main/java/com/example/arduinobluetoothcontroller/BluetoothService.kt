package com.example.arduinobluetoothcontroller

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Binder
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class BluetoothService : Service() {

    private val binder = LocalBinder()
    private var socket: BluetoothSocket? = null
    private val sppUuid: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    private var messageListener: ((String) -> Unit)? = null

    private val bluetoothAdapter: BluetoothAdapter? by lazy {
        val bluetoothManager = getSystemService(BluetoothManager::class.java)
        bluetoothManager.adapter
    }

    private val heartbeatHandler = Handler(Looper.getMainLooper())
    private val heartbeat = object : Runnable {
        override fun run() {
            if (isConnected()) {
                sendCommand("PING") {} // Add an empty lambda for now
            }
            heartbeatHandler.postDelayed(this, 2000)
        }
    }

    // Auto-reconnect variables
    private var lastConnectedDeviceAddress: String? = null
    private val reconnectHandler = Handler(Looper.getMainLooper())
    private val RECONNECT_DELAY_MS = 5000L // 5 seconds
    private var autoReconnectEnabled = false // Flag to control auto-reconnect

    // Foreground service constants
    private val NOTIFICATION_CHANNEL_ID = "BluetoothServiceChannel"
    private val NOTIFICATION_CHANNEL_NAME = "Bluetooth Service Notification"
    private val NOTIFICATION_ID = 101

    inner class LocalBinder : Binder() {
        fun getService(): BluetoothService = this@BluetoothService
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, createNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
    }

    override fun onBind(intent: Intent): IBinder = binder

    fun setMessageListener(listener: (String) -> Unit) {
        this.messageListener = listener
    }

    private fun startListening() {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val reader = BufferedReader(InputStreamReader(socket?.inputStream))
                while (socket?.isConnected == true) {
                    val line = reader.readLine() ?: break
                    Log.d("BluetoothService", "Received: $line")
                    messageListener?.invoke(line)
                }
            } catch (e: IOException) {
                Log.e("BluetoothService", "Read error: ${e.message}", e)
                // If the socket is no longer connected, it's a disconnect
                if (!isConnected() && autoReconnectEnabled) {
                    Log.d("BluetoothService", "Lost connection during read. Attempting reconnect...")
                    attemptDelayedReconnect()
                }
            }
        }
    }

    fun isConnected(): Boolean = socket?.isConnected == true

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val command = intent?.getStringExtra("command")
        val deviceAddress = intent?.getStringExtra("device_address")

        if (command != null && deviceAddress != null) {
            CoroutineScope(Dispatchers.IO).launch {
                connectAndSendCommand(deviceAddress, command)
            }
        }

        return START_STICKY // Changed to START_STICKY to keep service running
    }

    private fun connectAndSendCommand(deviceAddress: String, command: String) {
        val adapter = bluetoothAdapter ?: return
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            return
        }

        val device = adapter.getRemoteDevice(deviceAddress) ?: return

        try {
            socket?.close()
            socket = device.createRfcommSocketToServiceRecord(sppUuid)
            adapter.cancelDiscovery()
            socket?.connect()
            
            sendCurrentTimeToESP32()
            socket?.outputStream?.write((command + "\n").toByteArray())
            
            startListening()
            heartbeatHandler.post(heartbeat)
            lastConnectedDeviceAddress = deviceAddress
            startAutoReconnect()
        } catch (e: IOException) {
            Log.e("BluetoothService", "Error connecting and sending command: ${e.message}", e)
            stopAutoReconnect()
        }
    }

    private fun sendCurrentTimeToESP32() {
        try {
            val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
            val currentTime = sdf.format(Date())
            val timeCommand = "SETTIME $currentTime\n"
            socket?.outputStream?.write(timeCommand.toByteArray())
            Log.d("BluetoothService", "Time synced to ESP32: $currentTime")
        } catch (e: IOException) {
            Log.e("BluetoothService", "Failed to sync time", e)
        }
    }

    fun findAndConnect(deviceName: String, onResult: (Boolean, String?) -> Unit) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            onResult(false, null)
            return
        }
        val pairedDevice: BluetoothDevice? = bluetoothAdapter?.bondedDevices?.find { it.name == deviceName }

        if (pairedDevice == null) {
            onResult(false, null)
            return
        }

        connect(pairedDevice.address) { isSuccess ->
            onResult(isSuccess, pairedDevice.address)
        }
    }
    
    fun sendCommand(command: String, onResult: (Boolean) -> Unit) {
        if (socket?.isConnected == true) {
            try {
                socket?.outputStream?.write((command + "\n").toByteArray())
                onResult(true)
            } catch (e: IOException) {
                Log.e("BluetoothService", "Error sending command: ${e.message}", e)
                onResult(false)
                if (!isConnected() && autoReconnectEnabled) {
                    attemptDelayedReconnect()
                }
            }
        } else {
            onResult(false)
        }
    }

    fun connect(deviceAddress: String, onResult: (Boolean) -> Unit) {
        val adapter = bluetoothAdapter ?: run {
            onResult(false)
            return
        }
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
             onResult(false)
             return
        }
        val device = adapter.getRemoteDevice(deviceAddress) ?: run {
            onResult(false)
            return
        }
        CoroutineScope(Dispatchers.IO).launch {
            try {
                socket?.close()
                socket = device.createRfcommSocketToServiceRecord(sppUuid)
                socket?.connect()
                sendCurrentTimeToESP32()
                startListening()
                onResult(true)
                heartbeatHandler.post(heartbeat)
                lastConnectedDeviceAddress = deviceAddress
                startAutoReconnect()
            } catch (e: IOException) {
                Log.e("BluetoothService", "Connect error: ${e.message}", e)
                onResult(false)
                stopAutoReconnect()
            }
        }
    }

    fun disconnect() {
        stopAutoReconnect() // Stop auto-reconnect on intentional disconnect
        try {
            socket?.close()
            heartbeatHandler.removeCallbacks(heartbeat)
            socket = null // Clear socket reference
        } catch (e: IOException) {
             Log.e("BluetoothService", "Error closing socket: ${e.message}", e)
        }
    }

    override fun onDestroy() {
        disconnect()
        super.onDestroy()
    }

    private fun startAutoReconnect() {
        autoReconnectEnabled = true
        Log.d("BluetoothService", "Auto-reconnect started.")
    }

    private fun stopAutoReconnect() {
        autoReconnectEnabled = false
        reconnectHandler.removeCallbacksAndMessages(null) // Remove any pending reconnect attempts
        Log.d("BluetoothService", "Auto-reconnect stopped.")
    }

    private fun attemptDelayedReconnect() {
        reconnectHandler.removeCallbacksAndMessages(null) // Prevent multiple pending attempts
        reconnectHandler.postDelayed({
            if (autoReconnectEnabled && !isConnected()) {
                lastConnectedDeviceAddress?.let { address ->
                    Log.d("BluetoothService", "Executing delayed reconnect to $address")
                    connect(address) { isSuccess ->
                        if (isSuccess) {
                            Log.d("BluetoothService", "Reconnected successfully to $address")
                        } else {
                            Log.d("BluetoothService", "Failed to reconnect to $address. Retrying...")
                            attemptDelayedReconnect() // Retry again if failed
                        }
                    }
                } ?: Log.w("BluetoothService", "No lastConnectedDeviceAddress to reconnect to.")
            }
        }, RECONNECT_DELAY_MS)
    }

    private fun createNotificationChannel() {
        val serviceChannel = NotificationChannel(
            NOTIFICATION_CHANNEL_ID,
            NOTIFICATION_CHANNEL_NAME,
            NotificationManager.IMPORTANCE_LOW
        )
        val manager = getSystemService(NotificationManager::class.java)
        manager?.createNotificationChannel(serviceChannel)
    }

    private fun createNotification(): Notification {
        val notificationIntent = Intent(this, HomeActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, notificationIntent, PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
            .setContentTitle("Bluetooth Service")
            .setContentText("Maintaining Bluetooth connection...")
            .setSmallIcon(android.R.drawable.ic_dialog_info) // Replaced with a generic icon
            .setContentIntent(pendingIntent)
            .build()
    }
}
