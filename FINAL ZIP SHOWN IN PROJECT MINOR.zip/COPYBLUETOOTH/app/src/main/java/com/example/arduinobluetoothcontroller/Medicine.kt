package com.example.arduinobluetoothcontroller

data class Medicine(
    var name: String,
    var hour: Int = -1,
    var minute: Int = -1,
    var days: List<Int> = emptyList()
)