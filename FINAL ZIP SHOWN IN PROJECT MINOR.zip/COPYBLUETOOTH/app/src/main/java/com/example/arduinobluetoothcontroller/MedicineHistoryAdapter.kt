package com.example.arduinobluetoothcontroller

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class MedicineHistoryAdapter(private val medicines: List<Medicine>) : RecyclerView.Adapter<MedicineHistoryAdapter.HistoryViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HistoryViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.medicine_row, parent, false)
        return HistoryViewHolder(view)
    }

    override fun onBindViewHolder(holder: HistoryViewHolder, position: Int) {
        holder.bind(medicines[position])
    }

    override fun getItemCount() = medicines.size

    class HistoryViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val nameTextView: TextView = itemView.findViewById(R.id.medicine_name_text)
        private val timeTextView: TextView = itemView.findViewById(R.id.medicine_time_text)

        fun bind(medicine: Medicine) {
            nameTextView.text = medicine.name
            if (medicine.hour != -1 && medicine.minute != -1) {
                val time = String.format("%02d:%02d", medicine.hour, medicine.minute)
                val daysString = if (medicine.days.size == 7) {
                    "Daily"
                } else {
                    medicine.days.sorted().joinToString(", ") { getDayAbbreviation(it) }
                }
                timeTextView.text = "Time: $time | Days: $daysString"
                timeTextView.visibility = View.VISIBLE
            } else {
                timeTextView.visibility = View.GONE
            }
        }

        // This function now correctly maps the 0-6 integer format to the day abbreviation.
        private fun getDayAbbreviation(day: Int): String {
            return when (day) {
                0 -> "Sun"
                1 -> "Mon"
                2 -> "Tue"
                3 -> "Wed"
                4 -> "Thu"
                5 -> "Fri"
                6 -> "Sat"
                else -> ""
            }
        }
    }
}