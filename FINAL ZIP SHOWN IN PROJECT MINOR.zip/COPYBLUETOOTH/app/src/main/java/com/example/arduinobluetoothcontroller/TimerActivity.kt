package com.example.arduinobluetoothcontroller

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.IBinder
import android.view.MenuItem
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.example.arduinobluetoothcontroller.databinding.ActivityTimerBinding
import com.google.android.material.timepicker.MaterialTimePicker
import com.google.android.material.timepicker.TimeFormat

class TimerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityTimerBinding
    private var selectedHour: Int = -1
    private var selectedMinute: Int = -1
    private lateinit var medicineAdapter: ArrayAdapter<String>
    private var bluetoothService: BluetoothService? = null
    private var isBound = false

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(className: ComponentName, service: IBinder) {
            val binder = service as BluetoothService.LocalBinder
            bluetoothService = binder.getService()
            isBound = true
        }

        override fun onServiceDisconnected(arg0: ComponentName) {
            isBound = false
            AppLogger.logToHomeTerminal("Bluetooth Service Disconnected")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTimerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        setupSpinners()
        setupListeners()

        val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }
        permissionLauncher.launch(
            arrayOf(
                Manifest.permission.BLUETOOTH_CONNECT,
                Manifest.permission.BLUETOOTH_SCAN,
                Manifest.permission.ACCESS_FINE_LOCATION
            )
        )

        Intent(this, BluetoothService::class.java).also { intent ->
            bindService(intent, connection, Context.BIND_AUTO_CREATE)
        }
    }

    override fun onResume() {
        super.onResume()
        refreshMedicineSpinner()
    }

    private fun setupSpinners() {
        medicineAdapter = ArrayAdapter(this, R.layout.spinner_item, mutableListOf())
        medicineAdapter.setDropDownViewResource(R.layout.spinner_dropdown_item)
        binding.ledSpinner.adapter = medicineAdapter
        binding.ledSpinner.setPopupBackgroundResource(R.drawable.spinner_dropdown_background)

        val actionAdapter = ArrayAdapter.createFromResource(this, R.array.action_array, R.layout.spinner_item)
        actionAdapter.setDropDownViewResource(R.layout.spinner_dropdown_item)
        binding.actionSpinner.adapter = actionAdapter
        binding.actionSpinner.setPopupBackgroundResource(R.drawable.spinner_dropdown_background)
    }

    private fun refreshMedicineSpinner() {
        val medicineNames = MedicineData.medicineList.map { it.name }
        medicineAdapter.clear()
        medicineAdapter.addAll(medicineNames)
        medicineAdapter.notifyDataSetChanged()
    }

    private fun setupListeners() {
        binding.btnConnect.setOnClickListener { connectToESP32() }
        binding.timePickerButton.setOnClickListener { showTimePickerDialog() }
        binding.repeatDailySwitch.setOnCheckedChangeListener { _, isChecked ->
            binding.daysOfWeekLayout.visibility = if (isChecked) View.GONE else View.VISIBLE
        }
        binding.setTimerButton.setOnClickListener { setTimer() }
        binding.cancelTimerButton.setOnClickListener { cancelTimer() }
    }

    private fun showTimePickerDialog() {
        val picker = MaterialTimePicker.Builder()
            .setTimeFormat(TimeFormat.CLOCK_24H)
            .setHour(12)
            .setMinute(0)
            .setTitleText("Select Time")
            .build()

        picker.addOnPositiveButtonClickListener { 
            selectedHour = picker.hour
            selectedMinute = picker.minute
            binding.selectedTimeText.text = String.format("%02d:%02d", selectedHour, selectedMinute)
        }

        picker.show(supportFragmentManager, "tag")
    }

    private fun setTimer() {
        if (selectedHour == -1 || selectedMinute == -1) {
            Toast.makeText(this, "Please select a time", Toast.LENGTH_SHORT).show()
            return
        }
        if (binding.ledSpinner.selectedItem == null) {
            Toast.makeText(this, "Please add a medicine first", Toast.LENGTH_SHORT).show()
            return
        }
        
        // CRITICAL FIX: Ensure Bluetooth is actually connected before setting the alarm
        if (bluetoothService?.isConnected() != true) {
            Toast.makeText(this, "Please connect to the ESP32 first.", Toast.LENGTH_SHORT).show()
            return
        }

        val medicineIndex = binding.ledSpinner.selectedItemPosition
        val selectedMedicine = MedicineData.medicineList[medicineIndex]
        val ledId = medicineIndex + 1

        // Get all selected days from the UI
        val selectedDays = getSelectedDays()

        // Assign hour, minute, and the list of days to the local object
        selectedMedicine.hour = selectedHour
        selectedMedicine.minute = selectedMinute
        selectedMedicine.days = selectedDays

        // Save the updated data to SharedPreferences
        MedicineData.saveMedicines(this)

        // Build the days string for the Bluetooth command
        val daysString = if (selectedDays.isEmpty() || selectedDays.size == 7) {
            "EVERYDAY"
        } else {
            selectedDays.joinToString(",") { day ->
                when (day) {
                    0 -> "SUN"
                    1 -> "MON"
                    2 -> "TUE"
                    3 -> "WED"
                    4 -> "THU"
                    5 -> "FRI"
                    6 -> "SAT"
                    else -> ""
                }
            }
        }

        // Create and send the new command format
        val formattedTime = String.format("%02d:%02d", selectedHour, selectedMinute)
        val command = "ALARM $ledId $formattedTime $daysString"

        bluetoothService?.sendCommand(command) { success ->
            runOnUiThread {
                if (success) {
                    AppLogger.logToHomeTerminal("Alarm Set → LED$ledId $formattedTime $daysString")
                    Toast.makeText(this, "Alarm sent to ESP32", Toast.LENGTH_SHORT).show()
                    // Save to shared prefs for the Status Screen
                    val alarmInfo = "${selectedMedicine.name} at $formattedTime ($daysString)"
                    getSharedPreferences("MedicineApp", Context.MODE_PRIVATE)
                        .edit()
                        .putString("last_alarm_info", alarmInfo)
                        .apply()
                } else {
                    Toast.makeText(this, "Failed to send alarm to ESP32", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun cancelTimer() {
        val medicineIndex = binding.ledSpinner.selectedItemPosition
        if (medicineIndex < 0) return

        // Check for connection before canceling
        if (bluetoothService?.isConnected() != true) {
            Toast.makeText(this, "Please connect to the ESP32 first.", Toast.LENGTH_SHORT).show()
            return
        }

        val command = "ALARM ${medicineIndex + 1} 00:00 CLEAR"
        bluetoothService?.sendCommand(command) { success ->
            runOnUiThread {
                if (success) {
                    AppLogger.logToHomeTerminal("Alarm Canceled → LED${medicineIndex + 1}")
                    Toast.makeText(this, "Cancelled alarm on ESP32", Toast.LENGTH_SHORT).show()
                    val selectedMedicine = MedicineData.medicineList[medicineIndex]
                    selectedMedicine.hour = -1
                    selectedMedicine.minute = -1
                    selectedMedicine.days = emptyList()
                    MedicineData.saveMedicines(this)
                } else {
                    Toast.makeText(this, "Failed to cancel alarm", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun getSelectedDays(): List<Int> {
        val days = mutableListOf<Int>()
        if (binding.sundayToggle.isChecked) days.add(0)
        if (binding.mondayToggle.isChecked) days.add(1)
        if (binding.tuesdayToggle.isChecked) days.add(2)
        if (binding.wednesdayToggle.isChecked) days.add(3)
        if (binding.thursdayToggle.isChecked) days.add(4)
        if (binding.fridayToggle.isChecked) days.add(5)
        if (binding.saturdayToggle.isChecked) days.add(6)
        return days
    }
    
    private fun connectToESP32() {
        val deviceName = "ESP32_Controller"
        if (isBound && bluetoothService != null) {
            bluetoothService!!.findAndConnect(deviceName) { isSuccess, address ->
                runOnUiThread {
                    if (isSuccess) {
                        MedicineData.saveDeviceAddress(this, address)
                        AppLogger.logToHomeTerminal("Bluetooth Connected")
                        binding.btnConnect.text = "Connected"
                        binding.btnConnect.isEnabled = false
                    } else {
                        AppLogger.logToHomeTerminal("Bluetooth Disconnected")
                        Toast.makeText(this, "Connection Failed ❌", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            onBackPressedDispatcher.onBackPressed()
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isBound) {
            unbindService(connection)
            isBound = false
        }
    }
}
