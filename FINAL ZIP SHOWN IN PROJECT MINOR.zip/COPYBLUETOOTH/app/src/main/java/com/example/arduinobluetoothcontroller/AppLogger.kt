package com.example.arduinobluetoothcontroller

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object AppLogger {

    private var terminalListener: ((String) -> Unit)? = null

    fun setTerminalListener(listener: (String) -> Unit) {
        terminalListener = listener
    }

    fun clearTerminalListener() {
        terminalListener = null
    }

    fun logToHomeTerminal(msg: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        val formattedMsg = "[$time] $msg\n"
        terminalListener?.invoke(formattedMsg)
    }
}
