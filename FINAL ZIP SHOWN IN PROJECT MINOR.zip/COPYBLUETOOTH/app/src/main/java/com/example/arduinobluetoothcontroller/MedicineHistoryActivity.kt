package com.example.arduinobluetoothcontroller

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.arduinobluetoothcontroller.databinding.ActivityMedicineHistoryBinding

class MedicineHistoryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMedicineHistoryBinding
    private lateinit var historyAdapter: MedicineHistoryAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMedicineHistoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        setupRecyclerView()
    }

    override fun onResume() {
        super.onResume()
        // Refresh the adapter every time the activity is shown
        if (::historyAdapter.isInitialized) {
            historyAdapter.notifyDataSetChanged()
        }
    }

    private fun setupRecyclerView() {
        historyAdapter = MedicineHistoryAdapter(MedicineData.medicineList)
        binding.historyRecyclerView.apply {
            layoutManager = LinearLayoutManager(this@MedicineHistoryActivity)
            adapter = historyAdapter
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}