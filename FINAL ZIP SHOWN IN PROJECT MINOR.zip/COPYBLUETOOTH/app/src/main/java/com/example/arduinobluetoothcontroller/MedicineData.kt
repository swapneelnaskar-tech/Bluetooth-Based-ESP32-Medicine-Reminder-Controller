package com.example.arduinobluetoothcontroller

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

object MedicineData {
    val medicineList = mutableListOf<Medicine>()
    var deviceAddress: String? = null

    private const val PREFS_NAME = "MedicinePrefs"
    private const val MEDICINE_LIST_KEY = "MedicineList"
    private const val DEVICE_ADDRESS_KEY = "DeviceAddress"

    fun saveMedicines(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val editor = prefs.edit()
        val gson = Gson()
        val json = gson.toJson(medicineList)
        editor.putString(MEDICINE_LIST_KEY, json)
        editor.commit()
    }

    fun loadMedicines(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val gson = Gson()
        val json = prefs.getString(MEDICINE_LIST_KEY, null)
        val type = object : TypeToken<MutableList<Medicine>>() {}.type
        if (json != null) {
            medicineList.clear()
            medicineList.addAll(gson.fromJson(json, type))
        }
    }

    fun saveDeviceAddress(context: Context, address: String?) {
        deviceAddress = address
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val editor = prefs.edit()
        editor.putString(DEVICE_ADDRESS_KEY, address)
        editor.commit()
    }

    fun loadDeviceAddress(context: Context) {
        if (deviceAddress == null) {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            deviceAddress = prefs.getString(DEVICE_ADDRESS_KEY, null)
        }
    }
}