package com.example.arduinobluetoothcontroller

import android.Manifest
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.arduinobluetoothcontroller.databinding.ActivityHomeBinding
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class HomeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHomeBinding
    private var bluetoothService: BluetoothService? = null
    private var isBound = false
    private var isBluetoothConnected = false

    private val handler = Handler(Looper.getMainLooper())

    private val rtcUpdater = object : Runnable {
        override fun run() {
            // Log the current device time to the terminal every second
            logCurrentTime()

            val currentlyConnected = isBound && bluetoothService?.isConnected() == true
            if (currentlyConnected && !isBluetoothConnected) {
                // Connection just established, sync time
                sendTimeToDevice()
            }
            isBluetoothConnected = currentlyConnected

            if (isBluetoothConnected) {
                runOnUiThread { updateConnectionStatusUI(true) }
                // Only request the RSSI from ESP32
                bluetoothService?.sendCommand("GETRSSI") {}
            } else {
                runOnUiThread { updateConnectionStatusUI(false) }
            }
            handler.postDelayed(this, 1000)
        }
    }

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(className: ComponentName, service: IBinder) {
            val binder = service as BluetoothService.LocalBinder
            bluetoothService = binder.getService()
            isBound = true

            bluetoothService?.setMessageListener { message ->
                runOnUiThread {
                    handleBluetoothMessage(message)
                }
            }
        }

        override fun onServiceDisconnected(arg0: ComponentName) {
            isBound = false
            bluetoothService = null
            runOnUiThread { updateConnectionStatusUI(false) }
        }
    }

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        if (permissions[Manifest.permission.BLUETOOTH_CONNECT] == true) {
            startAndBindBluetoothService()
        } else {
            AppLogger.logToHomeTerminal("Bluetooth connect permission not granted. Service not started.")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayShowTitleEnabled(false)

        AppLogger.setTerminalListener {
            runOnUiThread {
                binding.tvTerminalHome.append(it)
                binding.terminalScroll.post {
                    binding.terminalScroll.fullScroll(View.FOCUS_DOWN)
                }
            }
        }

        binding.timerButton.setOnClickListener {
            startActivity(Intent(this, TimerActivity::class.java))
        }

        binding.medicineButton.setOnClickListener {
            startActivity(Intent(this, MedicineActivity::class.java))
        }

        binding.medicineHistoryButton.setOnClickListener {
            startActivity(Intent(this, MedicineHistoryActivity::class.java))
        }

        AppLogger.logToHomeTerminal("System online. Welcome!")

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED) {
                startAndBindBluetoothService()
            } else {
                requestPermissionLauncher.launch(arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN))
            }
        } else {
            startAndBindBluetoothService()
        }
    }

    private fun startAndBindBluetoothService() {
        val serviceIntent = Intent(this, BluetoothService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }
        bindService(serviceIntent, connection, Context.BIND_AUTO_CREATE)
    }

    private fun sendTimeToDevice() {
        val cal = Calendar.getInstance()
        val timeCmd = String.format(
            Locale.US,
            "SETTIME %04d-%02d-%02d %02d:%02d:%02d",
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH) + 1,
            cal.get(Calendar.DAY_OF_MONTH),
            cal.get(Calendar.HOUR_OF_DAY),
            cal.get(Calendar.MINUTE),
            cal.get(Calendar.SECOND)
        )
        bluetoothService?.sendCommand(timeCmd) { success ->
            if (success) {
                runOnUiThread {
                    AppLogger.logToHomeTerminal("RTC time synced with device.")
                }
            }
        }
    }

    private fun handleBluetoothMessage(message: String) {
        when {
            // We no longer handle RTC messages from the ESP32 here
            message.startsWith("RSSI") -> {
                message.substringAfter("RSSI ").trim().toIntOrNull()?.let {
                    updateBluetoothSignal(it)
                }
            }
            message.startsWith("ALARM TRIGGERED") -> {
                AppLogger.logToHomeTerminal("🔔 $message (FLASHING)")
                flashAlarm()
            }
        }
    }

    private fun logCurrentTime() {
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        val day = SimpleDateFormat("E", Locale.getDefault()).format(Date())
        AppLogger.logToHomeTerminal("RTC $time $day")
    }

    private fun updateBluetoothSignal(rssi: Int) {
        val (strengthText, bar) = when {
            rssi >= -67 -> "(Strong)" to "████████"
            rssi >= -70 -> "(Good)" to "███████"
            rssi >= -80 -> "(Fair)" to "█████"
            rssi >= -90 -> "(Weak)" to "███"
            else -> "(Very Weak)" to "█"
        }
        binding.tvBluetoothStatus.text = "Bluetooth: $bar $strengthText"
    }

    private fun updateConnectionStatusUI(connected: Boolean) {
        if (connected) {
            binding.tvBluetoothStatus.setTextColor(Color.GREEN)
            if (binding.tvBluetoothStatus.text.contains("Disconnected")) {
                binding.tvBluetoothStatus.text = "Bluetooth: Connected"
            }
        } else {
            binding.tvBluetoothStatus.text = "Bluetooth: Disconnected"
            binding.tvBluetoothStatus.setTextColor(Color.RED)
        }
    }

    private fun flashAlarm() {
        val animator = ValueAnimator.ofObject(ArgbEvaluator(), Color.YELLOW, Color.TRANSPARENT)
        animator.duration = 500 // 0.5 second
        animator.repeatCount = 10 // Flash for 5 seconds
        animator.repeatMode = ValueAnimator.REVERSE
        animator.addUpdateListener {
            binding.terminalScroll.setBackgroundColor(it.animatedValue as Int)
        }
        animator.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                binding.terminalScroll.setBackgroundColor(Color.BLACK)
            }
        })
        animator.start()
    }

    override fun onResume() {
        super.onResume()
        handler.post(rtcUpdater)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(rtcUpdater)
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isBound) {
            unbindService(connection)
            isBound = false
        }
        AppLogger.clearTerminalListener()
        handler.removeCallbacks(rtcUpdater)
    }
}
