package com.example.arduinobluetoothcontroller

import android.os.Bundle
import android.view.LayoutInflater
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.arduinobluetoothcontroller.databinding.ActivityMedicineBinding

class MedicineActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMedicineBinding
    private lateinit var medicineAdapter: MedicineAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMedicineBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        setupRecyclerView()

        binding.addMedicineFab.setOnClickListener {
            if (MedicineData.medicineList.size < 6) {
                showAddMedicineDialog()
            } else {
                Toast.makeText(this, "You can add a maximum of 6 medicines", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun setupRecyclerView() {
        medicineAdapter = MedicineAdapter(MedicineData.medicineList,
            object : MedicineAdapter.OnMedicineActionListener {
                override fun onEdit(medicine: Medicine, position: Int) {
                    showEditMedicineDialog(medicine, position)
                }

                override fun onDelete(position: Int) {
                    deleteMedicine(position)
                }
            }
        )
        binding.medicineRecyclerView.apply {
            layoutManager = LinearLayoutManager(this@MedicineActivity)
            adapter = medicineAdapter
        }
    }

    private fun showAddMedicineDialog() {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_medicine, null)
        val medicineNameInput = dialogView.findViewById<EditText>(R.id.medicine_name_input)

        AlertDialog.Builder(this)
            .setTitle("Add Medicine")
            .setView(dialogView)
            .setPositiveButton("Add") { _, _ ->
                val name = medicineNameInput.text.toString()
                if (name.isNotEmpty()) {
                    (binding.medicineRecyclerView.adapter as MedicineAdapter).addMedicine(Medicine(name))
                    MedicineData.saveMedicines(this)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showEditMedicineDialog(medicine: Medicine, position: Int) {
        val input = EditText(this)
        input.setText(medicine.name)

        AlertDialog.Builder(this)
            .setTitle("Edit Medicine")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val newName = input.text.toString().trim()
                if (newName.isNotEmpty()) {
                    medicine.name = newName
                    MedicineData.saveMedicines(this)
                    medicineAdapter.notifyItemChanged(position)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun deleteMedicine(position: Int) {
        AlertDialog.Builder(this)
            .setTitle("Delete medicine?")
            .setMessage("Are you sure you want to delete this medicine?")
            .setPositiveButton("Delete") { _, _ ->
                MedicineData.medicineList.removeAt(position)
                MedicineData.saveMedicines(this)
                medicineAdapter.notifyItemRemoved(position)
                medicineAdapter.notifyItemRangeChanged(position, MedicineData.medicineList.size)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}