package com.example.arduinobluetoothcontroller

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.RecyclerView

class MedicineAdapter(
    private val medicines: MutableList<Medicine>,
    private val listener: OnMedicineActionListener
) : RecyclerView.Adapter<MedicineAdapter.MedicineViewHolder>() {

    interface OnMedicineActionListener {
        fun onEdit(medicine: Medicine, position: Int)
        fun onDelete(position: Int)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MedicineViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.medicine_row, parent, false)
        return MedicineViewHolder(view)
    }

    override fun onBindViewHolder(holder: MedicineViewHolder, position: Int) {
        holder.bind(medicines[position])
        holder.itemView.setOnLongClickListener {
            showActionDialog(holder.itemView.context, position)
            true
        }
    }

    override fun getItemCount() = medicines.size

    fun addMedicine(medicine: Medicine) {
        medicines.add(medicine)
        notifyItemInserted(medicines.size - 1)
    }

    private fun showActionDialog(context: Context, position: Int) {
        AlertDialog.Builder(context)
            .setTitle("Medicine options")
            .setItems(arrayOf("Edit", "Delete")) { _, which ->
                when (which) {
                    0 -> listener.onEdit(medicines[position], position)
                    1 -> listener.onDelete(position)
                }
            }
            .show()
    }

    class MedicineViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        // This ViewHolder should only display the name of the medicine.
        private val nameTextView: TextView = itemView.findViewById(R.id.medicine_name_text)

        fun bind(medicine: Medicine) {
            nameTextView.text = medicine.name
        }
    }
}